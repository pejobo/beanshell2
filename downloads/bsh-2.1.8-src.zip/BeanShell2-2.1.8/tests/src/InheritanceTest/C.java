package InheritanceTest;

public interface C extends A {
	void c();
}
