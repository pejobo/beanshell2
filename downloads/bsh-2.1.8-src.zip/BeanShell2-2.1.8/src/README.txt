-- This is BeanShell2 --

BeanShell2 is a fork of http://www.beanshell.org/

For update and documentation see http://code.google.com/p/beanshell2

BeanShell2 is designed to work with versions of Java 1.5 and later
